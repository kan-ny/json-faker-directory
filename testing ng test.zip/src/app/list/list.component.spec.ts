import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { ListComponent } from './list.component';

describe('ListComponent', () => {
  let component: ListComponent;
  let fixture: ComponentFixture<ListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('List Component create', () => {
    expect(component).toBeTruthy();
  });


  it('Generating Review List', (() => {
    let fixture = TestBed.createComponent(ListComponent);
      fixture.detectChanges();
        let input = fixture.debugElement.query(By.css('.list-group'));
        let el = input.nativeElement;
        expect(input).toBeTruthy();
    })
  )

  


});
