import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  providers: [SharedService]

})
export class ListComponent implements OnInit {

  constructor(private _sharedService: SharedService) { }

  reviewList: any[] = [];

  adminStatus = false;

  ngOnInit(): void {
    console.log('list', this._sharedService.reviews);
    this.reviewList = this._sharedService.reviews;
    this.adminStatus = this._sharedService.adminStatus;
    
  }

  deleteItem(index: number, user: string){
    if(confirm("Confirm to delete Review by "+user)){
      this.reviewList = this._sharedService.deleteReview(index);
    }
    
  }

}
