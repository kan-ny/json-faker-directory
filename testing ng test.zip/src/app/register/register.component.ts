import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [SharedService]

})
export class RegisterComponent implements OnInit {
  register = { fname: '', lname: '', email: '', password: '', c_password: '', age: null, phone: null,  address: '', pincode: null}
  constructor(private _sharedService: SharedService) { }

  ngOnInit(): void {
  }

  onSubmit(){
    
    if (this.register.fname == '' || this.register.fname == ' ' || this.register.fname.length < 2){
      alert('Enter Valid First Name');
      return
    }

    if (this.register.lname == '' || this.register.lname == ' ' || this.register.lname.length < 2){
      alert('Enter Valid Last Name');
      return
    }

    if (!this.validateEmail(this.register.email)){
      alert('Invalid Email ID');
      return
    }

    if (this.register.password.length < 8){
      alert('Password must more than 8 characters');
      return
    }

    if (this.register.password !== this.register.c_password){
      alert('Password Not Matched');
      return
    }

    if (Number(this.register.age) > 18){
      alert('Minimum age is 18');
      return
    }

    if (String(this.register.phone).length < 10){
      alert('Enter 10 digit mobile number');
      return
    }


    if (this.register.address.length < 10){
      alert('Enter Complete address');
      return
    }


    if (String(this.register.pincode).length != 5){
      alert('Invalid Pincode');
      return
    }


    this._sharedService.emitUserRegistration({'type': 'register_user', val: this.register});

    alert('User Registred Successfully');
  }


validateEmail(email: string) 
    {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
    



}
