import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { RegisterComponent } from './register.component';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Component Created', () => {
    expect(component).toBeTruthy();
  });




it('User Registration Component first name not be empty and letters greater than 3', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
      let input = fixture.debugElement.query(By.css('.fname'));
      let el = input.nativeElement;
      expect(el.value).not.toBeNull();
      expect(el.value.length).toBeGreaterThan(3);
  })
)
it('User Registration Component last name not be empty and letters greater than 3', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.lname'));
      let el = input.nativeElement;
      expect(el.value).not.toBeNull();
  })
)
it('User Registration Component Password to be min of 6 characters, contains special symbol with upper and lower case.', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
      let input = fixture.debugElement.query(By.css('.password'));
      let el = input.nativeElement;
      expect(el.value).toMatch(regularExpression);
  })
)
it('User Registration Component email validation.', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    var re = /\S+@\S+\.\S+/;

    
      let input = fixture.debugElement.query(By.css('.emailid'));
      let el = input.nativeElement;
      expect(el.value).toMatch(re);
  })
)
it('User Registration Component validate confirm password', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input1 = fixture.debugElement.query(By.css('.c_password'));
      let input2 = fixture.debugElement.query(By.css('.password'));
      let e1 = input1.nativeElement;
      let e2 = input2.nativeElement;
      expect(e1.value == e2.value ).toBeTrue();
  })
)
it('User Registration Component validate age', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.age'));
      let el = input.nativeElement;
      expect(el.value).toBeGreaterThan(18);
  })
)
it('User Registration Component validate phone', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.phone'));
      let el = input.nativeElement;
      expect(el.value.length).toBe(10);
  })
)
it('User Registration Component validate address', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.address'));
      let el = input.nativeElement;
      expect(el.value.length).toBeGreaterThan(15);
     })
)
it('User Registration Component validate Zip code', (() => {
  let fixture = TestBed.createComponent(RegisterComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.pincode'));
      let el = input.nativeElement;
      expect(el.value.length).toBe(5);
  })
)
});
