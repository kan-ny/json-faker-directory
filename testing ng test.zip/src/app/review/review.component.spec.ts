import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { ReviewComponent } from './review.component';

describe('ReviewComponent', () => {
  let component: ReviewComponent;
  let fixture: ComponentFixture<ReviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Review Compoent Created', () => {
    expect(component).toBeTruthy();
  });



  it('Review Component Password Validation to be min of 6 characters, contains special symbol with upper and lower case.', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
        let input = fixture.debugElement.query(By.css('.password'));
        let el = input.nativeElement;
        expect(el.value).toMatch(regularExpression);
    })
  )
  it('Review Copmponent email validation.', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      var re = /\S+@\S+\.\S+/;
  
      
        let input = fixture.debugElement.query(By.css('.username'));
        let el = input.nativeElement;
        expect(el.value).toMatch(re);
    })
  )



  it('Review Copmponent Book Cost validation', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        let input = fixture.debugElement.query(By.css('.cost'));
        let el = input.nativeElement;
        expect(el.value).not.toBeNull();
    })
  );

  it('Review Copmponent Rating validation greater than 0 and less than 10', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        let input = fixture.debugElement.query(By.css('.rating'));
        let el = input.nativeElement;
        expect(el.value).not.toBeNull();
    })
  );

  it('Review Copmponent Favorite quote', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        let input = fixture.debugElement.query(By.css('.favorite_quote'));
        let el = input.nativeElement;
        expect(el.value).not.toBeNull();
    })
  );

  it('Review Copmponent Book Genre', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        let input = fixture.debugElement.query(By.css('.genre'));
        let el = input.nativeElement;
        expect(el.value).not.toBeNull();
        expect(el.value.length).toBeGreaterThan(4);
    })
  );

  it('Review Copmponent Page validation', (() => {
    let fixture = TestBed.createComponent(ReviewComponent);
      fixture.detectChanges();
      
        let input = fixture.debugElement.query(By.css('.pages'));
        let el = input.nativeElement;
        expect(el.value).not.toBeNull();
    })
  );

it('Review Copmponent Author Name', (() => {
  let fixture = TestBed.createComponent(ReviewComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.author'));
      let el = input.nativeElement;
      expect(el.value).not.toBeNull();
      expect(el.value.length).toBeGreaterThan(6);
  })
);

it('Review Copmponent book name validation', (() => {
  let fixture = TestBed.createComponent(ReviewComponent);
    fixture.detectChanges();
    
      let input = fixture.debugElement.query(By.css('.book_name'));
      let el = input.nativeElement;
      expect(el.value).not.toBeNull();
      expect(el.value.length).toBeGreaterThan(6)
  })
)

});
