import { Observable } from "rxjs";
import { Injectable } from "@angular/core";
// import { Subject } from "rxjs/Subject";
import {Subject} from 'rxjs';

@Injectable()
export class SharedService {

    public users : any[] = [

        { fname: 'rohit', lname: 'kumar', email: 'rohit@gmail.com', password: '123123123', c_password: '123123123', age: 24, phone: '7878789090',  address: 'medhipatnam hyderabad, TS', pincode: '50007'},
        { fname: 'ramu', lname: 'goud', email: 'ramu@gmail.com', password: '123456789', c_password: '123456789', age: 25, phone: '9090901212',  address: 'kazipet Warangal, TS', pincode: '10001'}

    ];

    public reviews: any[] = [
        { book_name: 'Harry Potter deathly hallows part 2',
        author: 'JK rowling', 
        pages: 417, 
        genre: 'Fantasy', 
        rating: 8, 
        user: 'Pranavi Reddy',
        cost: 37, 
        favorite_quote: 'Do not pity the dead, Harry. Pity the living and above all, those who live without love.', 
        book_review: 'Harry Potter is one of the most original and loved series ever. The plot is so interesting and unexpected. I could watch Harry Potter over and over without getting bored. I am sooo thankful for J.K Rowling for writing these series. Overall the Deathly Hallows is a great movie and I would totalllyyy recommend you to watch it.' }, 
        
        { book_name: 'Wings of Fire',
        author: 'A.P.J Abdul Kalam', 
        pages: 301, 
        genre: 'Inspiration', 
        rating: 10, 
        user: 'Rajitha',
        cost: 20, 
        favorite_quote: 'Be active! Take on responsibility! Work for the things you believe in. If you do not, you are surrendering your fate to others.', 
        book_review: 'This book is autobiography of Dr. A.P.J Abdul kalam. There is so much of knowledge and good things that everybody can extract from this book. Reading this book is a very heart warming and beautiful experience. This book contains a very detailed description of how great things can be achieved through simple thoughts. ' }
    ]

    

    public adminStatus = false;

    // Observable string sources
    private admin_login = new Subject<any>();
    // Observable string streams
    changeEmitted$ = this.admin_login.asObservable();
    // Service message commands
    emitChangeLogin(change: any) {
        this.adminStatus = change['val'];
        this.admin_login.next(change);
    }


    // for new Registred user
    // Observable string sources
    private user_registration = new Subject<any>();
    // Observable string streams
     changeEmitted2$ = this.user_registration.asObservable();
    // Service message commands
    emitUserRegistration(change: any) {
        this.users.push( change['val'] );
        this.user_registration.next(change);
     }



    // for all Registred user
    // Observable string sources
     private allusers = new Subject<any>();
     // Observable string streams
     changeEmitted3$ : Observable<any> = this.allusers.asObservable();

     // Service message commands
     emitAllUsers(change: any) {
         this.allusers.next(change);
     }

     private new_reviews = new Subject<any>();
     changeEmitReviews$ : Observable<any> = this.new_reviews.asObservable();
     emitNewReview(change: any){
         this.reviews.push(change);
         this.new_reviews.next(change);
     }

     deleteReview(index: number){
         this.reviews.splice(index, 1);
         return this.reviews;

     }


}