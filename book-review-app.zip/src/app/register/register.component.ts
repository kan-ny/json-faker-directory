import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [SharedService]

})
export class RegisterComponent implements OnInit {
  register = { fname: 'abcas', lname: 'asdads', email: 'asd@asd.in', password: '123123123', c_password: '123123123', age: 18, phone: '9876543210',  address: '101 Lakeshore Ave, Dayton, OH', pincode: '77881'}
  constructor(private _sharedService: SharedService) { }

  ngOnInit(): void {
  }

  onSubmit(){
    
    if (this.register.fname == '' || this.register.fname == ' ' || this.register.fname.length < 2){
      alert('Enter Valid First Name');
      return
    }

    if (this.register.lname == '' || this.register.lname == ' ' || this.register.lname.length < 2){
      alert('Enter Valid Last Name');
      return
    }

    if (!this.validateEmail(this.register.email)){
      alert('Invalid Email ID');
      return
    }

    if (this.register.password.length < 8){
      alert('Password must more than 8 characters');
      return
    }

    if (this.register.password !== this.register.c_password){
      alert('Password Not Matched');
      return
    }

    if (this.register.age > 18){
      alert('Minimum age is 18');
      return
    }

    if (String(this.register.phone).length < 10){
      alert('Enter 10 digit mobile number');
      return
    }


    if (this.register.address.length < 10){
      alert('Enter Complete address');
      return
    }


    if (String(this.register.pincode).length != 5){
      alert('Invalid Pincode');
      return
    }


    this._sharedService.emitUserRegistration({'type': 'register_user', val: this.register});

    alert('User Registred Successfully');
  }


validateEmail(email: string) 
    {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }
    



}
