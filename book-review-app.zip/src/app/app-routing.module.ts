import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from './list/list.component'
import { RegisterComponent } from './register/register.component'
import { ReviewComponent } from './review/review.component'
import { AdminComponent } from './admin/admin.component'

const routes: Routes = [
  { path: 'list', component: ListComponent},
  { path: 'review', component: ReviewComponent },
  { path: 'register', component:RegisterComponent },
  { path: 'admin', component:AdminComponent },
  { path: '**', redirectTo: '/list', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
