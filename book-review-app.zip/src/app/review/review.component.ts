import { Component, OnInit,  } from '@angular/core';
import { SharedService } from './../shared.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css'],
  providers: [SharedService]

})
export class ReviewComponent  {

  user_details : any;
  message='';
  username = 'ramu@gmail.com';
  password= '123456789';
  login = false;

  book_obj = { book_name: '',
  author: '', 
  pages: '', 
  genre: '', 
  rating: '', 
  cost: '', 
  favorite_quote: '', 
  book_review: '',
  user: '' };

  constructor(private _sharedService: SharedService) { }
  onSubmit() {
    console.log(this._sharedService.users, '...');
    this._sharedService.users.forEach(x=>{
      if(x['email'] === this.username && x['password'] === this.password){
        this.user_details = x;
        this.login = true;
      }else{
        this.user_details = '';
        this.login = false;
        this.message = 'Email or Password is incorrect.'
      }
    });
  }

  submitReview(){

    if( this.book_obj.book_name == '' || this.book_obj.book_name == ' '){
      alert('Enter Book Name');
      return;
    }
    if( this.book_obj.author == '' || this.book_obj.author == ' '){
      alert('Author Name cannot be empty');
      return;
    }
    if( this.book_obj.pages == null || this.book_obj.pages == ' '|| this.book_obj.pages == ''){
      alert('Enter Number of pages');
      return;
    }
    if( this.book_obj.genre == '' || this.book_obj.genre == ' ' ){
      alert('Enter Book Gener');
      return;
    }
    if( this.book_obj.rating == null || this.book_obj.rating == ' '|| this.book_obj.rating == '' ){
      alert('Give Rating from 1 to 10');
      return;
    }
    if( this.book_obj.cost == null ||this.book_obj.cost ==  ' '||this.book_obj.cost ==  ''){
      alert('Enter Book Cost');
      return;
    }
    if( this.book_obj.book_review == '' ||this.book_obj.book_review == ' '){
      alert('Enter Summary/Review of book.');
      return;
    }
  alert('Rewiew posted Successfully');

  this.book_obj['user'] = this.user_details['fname'] +" "+this.user_details['lname']

  this._sharedService.emitNewReview(this.book_obj);

  this.book_obj = { book_name: '',
  author: '', 
  pages: '', 
  genre: '', 
  rating: '', 
  cost: '', 
  favorite_quote: '', 
  book_review: '',
  user: '' };


    
  }

}
