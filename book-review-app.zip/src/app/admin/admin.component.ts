import { Component, OnInit, Input } from '@angular/core';
import { SharedService } from './../shared.service';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  providers: [SharedService],
})
export class AdminComponent implements OnInit {
  constructor(private _sharedService: SharedService) {}

  logout() {

    this.loginStatus['val'] = false;
    this.message=''
    this._sharedService.emitChangeLogin(this.loginStatus);

  }


  message='';

  loginStatus = {'type': 'adminLogin' ,'val': false};

  ngOnInit(): void {
   this.loginStatus['val'] = this._sharedService.adminStatus;
   
  }
  admin_password = 'password123';
  admin_name = 'admin';

  onSubmit(): void {
    // Process checkout data here
    console.log(this.admin_name, this.admin_password);

    if(this.admin_name === 'admin' && this.admin_password === 'password123' ){
      this.loginStatus['val'] = true;
      this.message='Logged in Successfully'
      this._sharedService.emitChangeLogin(this.loginStatus);

    }else{
      this.loginStatus['val'] = false;
      this._sharedService.emitChangeLogin(this.loginStatus);
      this.message='Incorrent username or passowrd. Try Again'
    }
  }




}
