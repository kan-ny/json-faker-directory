import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { AdminComponent } from './admin.component';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('Admin login username to be admin', (() => {
  let fixture = TestBed.createComponent(AdminComponent);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(By.css('.adminname'));
      let el = input.nativeElement;
      expect(el.value).toBe('admin');
     })
  })
)


it('Admin login password to be password123', (() => {
  let fixture = TestBed.createComponent(AdminComponent);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(By.css('.adminpassword'));
      let el = input.nativeElement;
      expect(el.value).toBe('password123');
     })
  })
)



});
