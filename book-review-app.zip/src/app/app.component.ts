import { Component, OnInit} from '@angular/core';
import {SharedService } from './shared.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [SharedService]
})
export class AppComponent  {

  admin_login = false;
  registredUser: any[] = [
 
  ];


  title = 'book-review';


  constructor(private _sharedService: SharedService) {

  this._sharedService.emitAllUsers(this.registredUser);

    _sharedService.changeEmitted$.subscribe(val => {
        if (val['type'] == 'adminLogin'){
          this.admin_login = val['val'];
        }
    });



    this._sharedService.changeEmitted2$.subscribe(val=>{
      if (val['type'] == 'register_user'){
        this.registredUser.push(val['val']);
        console.log('line 29', this.registredUser);
        
        this._sharedService.emitAllUsers(this.registredUser)
       }
    })

}


}
